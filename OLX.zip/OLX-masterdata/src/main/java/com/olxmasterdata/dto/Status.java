package com.olxmasterdata.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "This model shows info about status")
public class Status {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@ApiModelProperty(value = "Status is OPEN/CLOSED")
	private String status;
	
	public Status() {}
	
	public Status(int id, String status) {
		super();
		this.id = id;
		this.status = status;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "Status [id=" + id + ", status=" + status + "]";
	}
}
