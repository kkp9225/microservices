package com.olxmasterdata.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(value = "This Model holds information about Categories")
public class MasterData {

	private int id;
	@ApiModelProperty(value = "Catogery name")
	private String category;
	@ApiModelProperty(value = "Catogery status")
	private String status;
	
	public MasterData() {}
	
	public MasterData(int id, String category, String status) {
		super();
		this.id = id;
		this.category = category;
		this.status = status;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "MasterData [id=" + id + ", category=" + category + ", status=" + status + "]";
	}
}
