package com.olxmasterdata.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.olxmasterdata.repo.StatusRepo;
import com.olxmasterdata.service.StatusService;

@Service
public class StatusServiceImpl implements StatusService{

	@Autowired
	StatusRepo statusRepo;
}
