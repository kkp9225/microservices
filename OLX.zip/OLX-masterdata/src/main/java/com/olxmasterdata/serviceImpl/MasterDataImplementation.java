package com.olxmasterdata.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.olxmasterdata.dto.MasterData;
import com.olxmasterdata.dto.Status;
import com.olxmasterdata.entity.MasterDataEntity;
import com.olxmasterdata.entity.StatusEntity;
import com.olxmasterdata.repo.MasterDataRepo;
import com.olxmasterdata.repo.StatusRepo;
import com.olxmasterdata.service.MasterDataService;

@Service
public class MasterDataImplementation implements MasterDataService{

	@Autowired
	MasterDataRepo masterDataRepo;
	
	@Autowired
	StatusRepo statusRepo;

	@Override
	public List<MasterData> findAll() {
		List<MasterDataEntity> masterDataEntities = masterDataRepo.findAll();
		List<MasterData> masterDatas = new ArrayList(); 
		for(MasterDataEntity masterDataEntity: masterDataEntities) {
			MasterData masterData = new MasterData(masterDataEntity.getId(), masterDataEntity.getCategory(), masterDataEntity.getStatus());
			masterDatas.add(masterData); 
		}
		System.out.println("All master data are " + masterDatas);
		return masterDatas;
	}

	@Override
	public List<Status> findAllStatus() {
		List<StatusEntity> statusEntities = statusRepo.findAll();
		List<Status> statuses = new ArrayList<>();
		for(StatusEntity statusEntity : statusEntities) {
			Status status = new Status(statusEntity.getId(), statusEntity.getStatus());
			statuses.add(status);
		}
		System.out.println("All statuses data are " + statuses);
		return statuses;
	}
}
