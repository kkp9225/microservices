package com.olxmasterdata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olxmasterdata.entity.StatusEntity;

public interface StatusRepo extends JpaRepository<StatusEntity, Integer>{

}
