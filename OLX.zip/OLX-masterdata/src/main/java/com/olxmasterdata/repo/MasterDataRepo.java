package com.olxmasterdata.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olxmasterdata.entity.MasterDataEntity;

public interface MasterDataRepo extends JpaRepository<MasterDataEntity, Integer>{

}
