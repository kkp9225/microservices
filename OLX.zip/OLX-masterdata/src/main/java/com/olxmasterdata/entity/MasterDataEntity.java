package com.olxmasterdata.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "categories")
public class MasterDataEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	@ApiModelProperty(value = "Catogery name")
	private String category;
	@ApiModelProperty(value = "Catogery status")
	private String status;
	
	public MasterDataEntity() {}
	
	public MasterDataEntity(String category, String status) {
		super();
		this.category = category;
		this.status = status;
	}
	
	public MasterDataEntity(int id, String category, String status) {
		super();
		this.id = id;
		this.category = category;
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "MasterDataEntity [id=" + id + ", category=" + category + ", status=" + status + "]";
	}

}
