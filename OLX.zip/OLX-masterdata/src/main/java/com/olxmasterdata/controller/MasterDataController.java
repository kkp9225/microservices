package com.olxmasterdata.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olxmasterdata.dto.MasterData;
import com.olxmasterdata.dto.Status;
import com.olxmasterdata.service.MasterDataService;

import io.swagger.annotations.ApiOperation;

@RestController
public class MasterDataController {

	@Autowired
	MasterDataService masterDataService;
	
	@PostMapping("/hi")
	public ResponseEntity<?> sayHi(){
		return new ResponseEntity<>("HI! Welcome to Springboot Microservices", HttpStatus.OK);
	}
	
	@GetMapping("/advertise/category")
	@ApiOperation(value = "This service returns categories")
	public ResponseEntity<?> category(){
		List<MasterData> masterArrList = new ArrayList<>();
		masterArrList = masterDataService.findAll();
 		return new ResponseEntity<>(masterArrList, HttpStatus.OK);
	}
	
	@GetMapping("/advertise/status")
	@ApiOperation(value = "This service returns status")
	public ResponseEntity<?> status(){
		List<Status> statusArrList = new ArrayList<>();
		statusArrList = masterDataService.findAllStatus();
		return new ResponseEntity<>(statusArrList, HttpStatus.OK);
	}

}
