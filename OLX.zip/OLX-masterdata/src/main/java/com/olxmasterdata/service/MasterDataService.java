package com.olxmasterdata.service;

import java.util.List;

import com.olxmasterdata.dto.MasterData;
import com.olxmasterdata.dto.Status;

public interface MasterDataService {

	List<MasterData> findAll();

	List<Status> findAllStatus();

}
