package com.olxadvertise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlxAdvertiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
