package com.olxadvertise.service;

public interface UserServiceDelegate {
	
	Boolean isValidUser(String auth_token);
}
